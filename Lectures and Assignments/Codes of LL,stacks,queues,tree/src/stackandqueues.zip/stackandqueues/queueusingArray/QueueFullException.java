package stackandqueues.queueusingArray;

public class QueueFullException extends Exception {

}
