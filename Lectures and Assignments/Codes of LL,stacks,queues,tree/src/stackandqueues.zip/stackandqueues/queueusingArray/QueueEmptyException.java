package stackandqueues.queueusingArray;

public class QueueEmptyException extends Exception {

}
