package stackandqueues.queueusinglinkedlist;

public class QueueUnderFlowException extends Exception {

}
